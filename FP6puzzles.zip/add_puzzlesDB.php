<?php
    $table = $_GET['query'];
   	
	include 'db_configuration.php'; 
	
    $Queries = explode('|',$table);
    //update database table for every query
    foreach($Queries as $Query)
        
        $result = mysqli_query($db, $Query);
    
    if($result){
     echo("<h3>record successfuly added to the database table.</h3>");
        ////header("Location: list_puzzles.php");
        //window.location='edit_puzzles.php?id='.$id; /* Redirect browser */
        
    }else{
        echo("<h3>failed to update record".mysqli_error($db)."</h3>");
    } 
    
    // add two buttons for Home ane return
	exit();
?>